import openai
from app.core.config import settings
import asyncio

openai.api_key = settings.OPENAI_API_KEY

async def get_ai_response(customer_message: str, business_data: dict) -> str:
    try:
        system_prompt = business_data.get('system_prompt', f"""You are a helpful customer service AI for {business_data.get('business_name', 'our business')}.
Business Info:
- Timings: {business_data.get('opening_time')} to {business_data.get('closing_time')}
- Location: {business_data.get('business_location')}
- Pricing: {business_data.get('pricing_info')}
- FAQs: {business_data.get('faqs')}
Respond in Hindi/English. Keep response short and helpful.""")

        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": customer_message}
                ],
                temperature=0.7,
                max_tokens=150
            )
        )
        
        return response.choices[0].message.content
    except Exception as e:
        return f"Sorry, couldn't process your message. Error: {str(e)}"
