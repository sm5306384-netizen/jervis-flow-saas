import express from 'express';
import { default as makeWASocket, useMultiFileAuthState, DisconnectReason } from '@whiskeysockets/baileys';
import qrcode from 'qrcode-terminal';
import dotenv from 'dotenv';
import pino from 'pino';
import axios from 'axios';

dotenv.config();

const app = express();
app.use(express.json());

let sock = null;

app.get('/health', (req, res) => {
    const status = sock?.user ? 'connected' : 'disconnected';
    res.json({ status: 'healthy', whatsapp_status: status, service: 'whatsapp-bridge', version: '1.0.0' });
});

app.get('/qr-status', (req, res) => {
    const isConnected = sock?.user ? true : false;
    res.json({ connected: isConnected, phone_number: sock?.user?.id || 'Not Connected' });
});

async function connectWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    
    sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
        logger: pino({ level: 'silent' })
    });

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;
        if (qr) {
            console.log('?? Scan QR Code:');
            qrcode.generate(qr, { small: true });
        }
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) connectWhatsApp();
        } else if (connection === 'open') {
            console.log('? WhatsApp Connected!');
        }
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0];
        if (!msg.message) return;
        const msgText = msg.message.conversation || '';
        console.log(?? From: );
        try {
            const response = await axios.post(${process.env.BACKEND_URL}, {
                from: msg.key.remoteJid,
                message_text: msgText,
                timestamp: msg.messageTimestamp,
                message_id: msg.key.id
            });
            const aiResponse = response.data.reply;
            await sock.sendMessage(msg.key.remoteJid, { text: aiResponse });
            console.log(? Reply sent!);
        } catch (error) {
            console.error('Error:', error.message);
        }
    });
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(?? WhatsApp Bridge on http://localhost:);
    connectWhatsApp();
});
