from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import uuid

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    phone = Column(String(20), nullable=False, unique=True, index=True)
    password = Column(String(255), nullable=False)
    email = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Business(Base):
    __tablename__ = "businesses"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, nullable=False, index=True)
    business_name = Column(String(255), nullable=False)
    owner_phone = Column(String(20), nullable=False, unique=True)
    owner_email = Column(String(255), nullable=False)
    business_category = Column(String(100), nullable=False)
    business_location = Column(String(255), nullable=False)
    opening_time = Column(String(10), nullable=True)
    closing_time = Column(String(10), nullable=True)
    business_description = Column(Text, nullable=True)
    pricing_info = Column(JSON, nullable=True)
    faqs = Column(JSON, nullable=True)
    whatsapp_number = Column(String(20), nullable=True, unique=True)
    is_whatsapp_connected = Column(Boolean, default=False)
    system_prompt = Column(Text, nullable=True)
    api_key = Column(String(255), nullable=False, unique=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class WhatsAppMessage(Base):
    __tablename__ = "whatsapp_messages"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    business_id = Column(String, nullable=False, index=True)
    customer_phone = Column(String(20), nullable=False)
    message_text = Column(Text, nullable=False)
    ai_response = Column(Text, nullable=False)
    response_time_ms = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
