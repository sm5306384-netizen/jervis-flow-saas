import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Dashboard() {
  const [businessName, setBusinessName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [category, setCategory] = useState('gym');
  const [location, setLocation] = useState('');
  const [openingTime, setOpeningTime] = useState('09:00');
  const [closingTime, setClosingTime] = useState('21:00');
  const [pricing, setPricing] = useState('');
  const [faqs, setFaqs] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    try {
      const response = await axios.post(${process.env.REACT_APP_API_URL}/api/v1/business/create?token=, {
        business_name: businessName, owner_phone: ownerPhone, owner_email: ownerEmail, business_category: category, business_location: location, opening_time: openingTime, closing_time: closingTime, pricing_info: JSON.parse(pricing || '{}'), faqs: JSON.parse(faqs || '[]')
      });
      alert('Business created!');
      navigate('/connect-whatsapp', { state: { businessId: response.data.id } });
    } catch (error) {
      alert('Error: ' + (error.response?.data?.detail || 'Failed'));
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h1>Dashboard</h1>
        <button onClick={handleLogout} style={{ padding: '10px 20px', backgroundColor: '#dc3545', color: 'white', border: 'none', cursor: 'pointer' }}>Logout</button>
      </div>
      <form onSubmit={handleSubmit} style={{ maxWidth: '600px', backgroundColor: 'white', padding: '20px' }}>
        <input type="text" placeholder="Business Name" value={businessName} onChange={(e) => setBusinessName(e.target.value)} required style={{ width: '100%', padding: '10px', marginBottom: '10px' }} />
        <input type="text" placeholder="Owner Phone" value={ownerPhone} onChange={(e) => setOwnerPhone(e.target.value)} required style={{ width: '100%', padding: '10px', marginBottom: '10px' }} />
        <input type="email" placeholder="Owner Email" value={ownerEmail} onChange={(e) => setOwnerEmail(e.target.value)} required style={{ width: '100%', padding: '10px', marginBottom: '10px' }} />
        <select value={category} onChange={(e) => setCategory(e.target.value)} style={{ width: '100%', padding: '10px', marginBottom: '10px' }}><option value="gym">Gym</option><option value="salon">Salon</option></select>
        <input type="text" placeholder="Location" value={location} onChange={(e) => setLocation(e.target.value)} required style={{ width: '100%', padding: '10px', marginBottom: '10px' }} />
        <input type="time" value={openingTime} onChange={(e) => setOpeningTime(e.target.value)} style={{ width: '100%', padding: '10px', marginBottom: '10px' }} />
        <input type="time" value={closingTime} onChange={(e) => setClosingTime(e.target.value)} style={{ width: '100%', padding: '10px', marginBottom: '10px' }} />
        <textarea placeholder='Pricing (JSON)' value={pricing} onChange={(e) => setPricing(e.target.value)} style={{ width: '100%', padding: '10px', marginBottom: '10px', minHeight: '80px' }} />
        <textarea placeholder='FAQs (JSON)' value={faqs} onChange={(e) => setFaqs(e.target.value)} style={{ width: '100%', padding: '10px', marginBottom: '10px', minHeight: '80px' }} />
        <button type="submit" style={{ width: '100%', padding: '10px', backgroundColor: '#28a745', color: 'white', border: 'none', cursor: 'pointer' }}>Save & Connect WhatsApp</button>
      </form>
    </div>
  );
}
