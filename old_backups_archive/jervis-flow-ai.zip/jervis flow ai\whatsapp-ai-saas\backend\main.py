from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os
from dotenv import load_dotenv
import logging

load_dotenv()

app = FastAPI(
    title="WhatsApp AI SaaS",
    description="Self-Hosted WhatsApp Business Automation",
    version="1.0.0"
)

origins = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000,http://localhost:8000").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logger = logging.getLogger(__name__)

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "whatsapp-ai-saas-backend",
        "version": "1.0.0"
    }

@app.get("/")
def root():
    return {"message": "WhatsApp AI SaaS Backend Running ?"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
